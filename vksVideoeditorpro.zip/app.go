package main

import (
        "context"
        "encoding/json"
        "errors"
        "fmt"
        "os"
        "os/exec"
        "path/filepath"
        "runtime"
        "strings"
        "sync"
        "time"

        "github.com/wailsapp/wails/v2/pkg/options"
        wruntime "github.com/wailsapp/wails/v2/pkg/runtime"

        "vkseditorpro/internal/media"
        "vkseditorpro/internal/project"
)

// App là cầu nối giữa giao diện (WebView) và backend Go.
// Mọi method export (viết hoa) của struct này đều được Wails tự bind cho JS.
type App struct {
        ctx context.Context

        version string

        dataDir    string // %APPDATA%/VKSeditorPro — project.json, settings
        thumbsDir  string // cache thumbnail (/local/thumbs)
        framesDir  string // cache khung hình xem trước (/local/frames)
        previewDir string // bản xem trước render (/local/preview)
        proxyDir   string // bản proxy 480p (/local/proxy)
        ttsDir     string // file giọng đọc TTS (/local/tts)

        store *project.Store

        mu  sync.RWMutex // bảo vệ doc
        doc *project.Document

        jobMu   sync.Mutex // một tác vụ nặng tại một thời điểm
        jobName string
        cancel  context.CancelFunc
}

// NewApp khởi tạo App và các thư mục dữ liệu.
func NewApp() (*App, error) {
        cfg, err := os.UserConfigDir()
        if err != nil {
                return nil, err
        }
        dataDir := filepath.Join(cfg, "VKSeditorPro")
        for _, d := range []string{dataDir, filepath.Join(dataDir, "thumbs"), filepath.Join(dataDir, "frames"), filepath.Join(dataDir, "preview"), filepath.Join(dataDir, "proxies"), filepath.Join(dataDir, "tts")} {
                if err := os.MkdirAll(d, 0o755); err != nil {
                        return nil, err
                }
        }
        store, err := project.NewStore(dataDir)
        if err != nil {
                return nil, err
        }
        doc, err := store.Load()
        if err != nil {
                // File hỏng — bắt đầu mới thay vì chết app.
                doc = project.NewDocument()
        }
        return &App{
                version:    AppVersion,
                dataDir:    dataDir,
                thumbsDir:  filepath.Join(dataDir, "thumbs"),
                framesDir:  filepath.Join(dataDir, "frames"),
                previewDir: filepath.Join(dataDir, "preview"),
                proxyDir:   filepath.Join(dataDir, "proxies"),
                ttsDir:     filepath.Join(dataDir, "tts"),
                store:      store,
                doc:        doc,
        }, nil
}

// startup được gọi bởi Wails khi ứng dụng khởi động.
func (a *App) startup(ctx context.Context) {
        a.ctx = ctx
        // Kéo-thả tệp vào cửa sổ → tự nhập vào thư viện.
        wruntime.OnFileDrop(ctx, func(x, y int, paths []string) {
                if _, err := a.AddAssets(paths); err != nil {
                        // Báo qua sự kiện để UI hiện toast.
                        wruntime.EventsEmit(a.ctx, "import:error", map[string]any{"message": err.Error()})
                } else {
                        wruntime.EventsEmit(a.ctx, "import:done", nil)
                }
        })
        // Đánh dấu asset thiếu nếu tệp nguồn không còn.
        changed := false
        a.mu.Lock()
        for _, as := range a.doc.Assets {
                if _, err := os.Stat(as.Path); err != nil {
                        if !as.Missing {
                                as.Missing = true
                                changed = true
                        }
                }
        }
        a.mu.Unlock()
        if changed {
                _ = a.persist()
        }
}

// shutdown được gọi khi ứng dụng đóng — huỷ tác vụ đang chạy.
func (a *App) shutdown(ctx context.Context) {
        a.jobMu.Lock()
        if a.cancel != nil {
                a.cancel()
        }
        a.jobMu.Unlock()
}

// onSecondInstance — lần chạy thứ 2 chỉ đưa cửa sổ cũ lên trước.
func (a *App) onSecondInstance(_ options.SecondInstanceData) {
        wruntime.WindowUnminimise(a.ctx)
        wruntime.WindowSetAlwaysOnTop(a.ctx, true)
        wruntime.WindowSetAlwaysOnTop(a.ctx, false)
}

// ---------------------------------------------------------------------------
// Trạng thái & dự án
// ---------------------------------------------------------------------------

// StateResponse là toàn bộ trạng thái trả về cho frontend lúc khởi động.
type StateResponse struct {
        Doc        *project.Document `json:"doc"`
        Version    string            `json:"version"`
        DataDir    string            `json:"dataDir"`
        PreviewURL string            `json:"previewUrl"`
        OS         string            `json:"os"`
}

// cloneDoc tạo bản sao độc lập của document (an toàn luồng).
func (a *App) cloneDoc() *project.Document {
        a.mu.RLock()
        defer a.mu.RUnlock()
        b, _ := json.Marshal(a.doc)
        var d project.Document
        _ = json.Unmarshal(b, &d)
        return &d
}

// persist lưu document hiện tại xuống đĩa.
func (a *App) persist() error {
        a.mu.RLock()
        doc := a.doc
        a.mu.RUnlock()
        return a.store.Save(doc)
}

// GetState trả trạng thái đầy đủ cho frontend.
func (a *App) GetState() (*StateResponse, error) {
        return &StateResponse{
                Doc:        a.cloneDoc(),
                Version:    a.version,
                DataDir:    a.dataDir,
                PreviewURL: a.previewURL(),
                OS:         runtime.GOOS,
        }, nil
}

// NewProject tạo dự án trắng (giữ thư viện nếu giữLibrary = true).
func (a *App) NewProject(keepLibrary bool) error {
        a.mu.Lock()
        old := a.doc
        nd := project.NewDocument()
        if keepLibrary {
                nd.Assets = old.Assets
        }
        a.doc = nd
        a.mu.Unlock()
        return a.persist()
}

// SaveProject lưu dự án vào vị trí mặc định (project.json).
func (a *App) SaveProject() (string, error) {
        if err := a.persist(); err != nil {
                return "", err
        }
        return a.store.Path(), nil
}

// SaveProjectAs mở hộp thoại lưu và ghi bản sao .vksproj.
func (a *App) SaveProjectAs() (string, error) {
        path, err := wruntime.SaveFileDialog(a.ctx, wruntime.SaveDialogOptions{
                Title:           "Lưu dự án",
                DefaultFilename: a.cloneDoc().Name + ".vksproj",
                Filters: []wruntime.FileFilter{
                        {DisplayName: "Dự án VKSeditorPro (*.vksproj)", Pattern: "*.vksproj"},
                },
        })
        if err != nil || path == "" {
                return "", err
        }
        doc := a.cloneDoc()
        b, err := json.MarshalIndent(doc, "", "  ")
        if err != nil {
                return "", err
        }
        if err := os.WriteFile(path, b, 0o644); err != nil {
                return "", err
        }
        return path, nil
}

// OpenProjectDialog mở hộp thoại chọn .vksproj và nạp vào app.
func (a *App) OpenProjectDialog() (*project.Document, error) {
        path, err := wruntime.OpenFileDialog(a.ctx, wruntime.OpenDialogOptions{
                Title: "Mở dự án",
                Filters: []wruntime.FileFilter{
                        {DisplayName: "Dự án VKSeditorPro (*.vksproj)", Pattern: "*.vksproj"},
                },
        })
        if err != nil || path == "" {
                return nil, err
        }
        b, err := os.ReadFile(path)
        if err != nil {
                return nil, err
        }
        var doc project.Document
        if err := json.Unmarshal(b, &doc); err != nil {
                return nil, fmt.Errorf("file dự án không hợp lệ: %w", err)
        }
        // sanitize như store.Load
        tmpStore, err := project.NewStore(filepath.Join(os.TempDir(), "vks-sanitize"))
        if err == nil {
                _ = tmpStore.Save(&doc)
                if fresh, err2 := tmpStore.Load(); err2 == nil {
                        doc = *fresh
                }
                _ = os.RemoveAll(filepath.Join(os.TempDir(), "vks-sanitize"))
        }
        for _, as := range doc.Assets {
                if _, err := os.Stat(as.Path); err != nil {
                        as.Missing = true
                }
        }
        a.mu.Lock()
        a.doc = &doc
        a.mu.Unlock()
        if err := a.persist(); err != nil {
                return nil, err
        }
        return a.cloneDoc(), nil
}

// SetCanvas đặt kích thước khung + frame rate của dự án.
func (a *App) SetCanvas(w, h, num, den int) error {
        if w < 64 || w > 7680 || h < 64 || h > 4320 || num <= 0 || den <= 0 {
                return errors.New("tham số canvas không hợp lệ")
        }
        a.mu.Lock()
        a.doc.Canvas = project.Canvas{Width: w, Height: h, Rate: project.Rate{Num: num, Den: den}}
        a.mu.Unlock()
        return a.persist()
}

// ---------------------------------------------------------------------------
// Thư viện tư liệu
// ---------------------------------------------------------------------------

// ImportMediaDialog mở hộp thoại chọn nhiều tệp rồi nhập vào thư viện.
func (a *App) ImportMediaDialog() ([]*project.Asset, error) {
        paths, err := wruntime.OpenMultipleFilesDialog(a.ctx, wruntime.OpenDialogOptions{
                Title: "Nhập tư liệu (video / ảnh / âm thanh)",
                Filters: []wruntime.FileFilter{
                        {DisplayName: "Tất cả định dạng hỗ trợ", Pattern: "*.mp4;*.mov;*.mkv;*.webm;*.avi;*.m4v;*.wmv;*.flv;*.ts;*.png;*.jpg;*.jpeg;*.webp;*.bmp;*.gif;*.mp3;*.wav;*.m4a;*.aac;*.ogg;*.flac"},
                        {DisplayName: "Video", Pattern: "*.mp4;*.mov;*.mkv;*.webm;*.avi;*.m4v;*.wmv;*.flv"},
                        {DisplayName: "Ảnh", Pattern: "*.png;*.jpg;*.jpeg;*.webp;*.bmp;*.gif"},
                        {DisplayName: "Âm thanh", Pattern: "*.mp3;*.wav;*.m4a;*.aac;*.ogg;*.flac"},
                },
        })
        if err != nil {
                return nil, err
        }
        if len(paths) == 0 {
                return nil, nil
        }
        return a.AddAssets(paths)
}

// AddAssets nhập danh sách tệp vào thư viện (probe + thêm + lưu).
func (a *App) AddAssets(paths []string) ([]*project.Asset, error) {
        var added []*project.Asset
        var errs []string
        for _, p := range paths {
                if !media.Importable(p) {
                        errs = append(errs, fmt.Sprintf("%s: định dạng không hỗ trợ", filepath.Base(p)))
                        continue
                }
                as, err := media.Probe(p)
                if err != nil {
                        errs = append(errs, fmt.Sprintf("%s: %v", filepath.Base(p), err))
                        continue
                }
                as.ID = project.NewID("a")
                a.mu.Lock()
                // Tránh nhập trùng cùng 1 tệp.
                dup := false
                for _, ex := range a.doc.Assets {
                        if ex.Path == as.Path && !ex.Missing {
                                dup = true
                                break
                        }
                }
                if dup {
                        a.mu.Unlock()
                        continue
                }
                a.doc.Assets = append(a.doc.Assets, as)
                a.mu.Unlock()
                added = append(added, as)
        }
        if err := a.persist(); err != nil {
                return added, err
        }
        if len(errs) > 0 {
                return added, errors.New(strings.Join(errs, "\n"))
        }
        return added, nil
}

// RemoveAsset xoá tư liệu khỏi thư viện (kèm xoá các clip đang dùng nó).
func (a *App) RemoveAsset(id string) error {
        a.mu.Lock()
        var kept []*project.Asset
        found := false
        for _, as := range a.doc.Assets {
                if as.ID == id {
                        found = true
                        continue
                }
                kept = append(kept, as)
        }
        if !found {
                a.mu.Unlock()
                return fmt.Errorf("không tìm thấy tư liệu %s", id)
        }
        a.doc.Assets = kept
        // Xoá clip tham chiếu + chuyển cảnh nối vào chúng.
        var clips []*project.Clip
        for _, c := range a.doc.Clips {
                if c.AssetID == id {
                        a.doc.RemoveTransitionAfter(c.ID)
                        continue
                }
                clips = append(clips, c)
        }
        a.doc.Clips = clips
        a.doc.Transitions = cleanTransitions(a.doc)
        a.mu.Unlock()
        return a.persist()
}

// GetAssetThumb tạo (nếu cần) và trả URL thumbnail cho tư liệu tại tMs.
func (a *App) GetAssetThumb(assetID string, tMs int64) (string, error) {
        a.mu.RLock()
        as := a.doc.FindAsset(assetID)
        a.mu.RUnlock()
        if as == nil {
                return "", fmt.Errorf("không tìm thấy tư liệu %s", assetID)
        }
        if as.Missing {
                return "", fmt.Errorf("tệp nguồn không còn: %s", as.Path)
        }
        path, err := media.EnsureThumbnail(a.ctx, as, a.thumbsDir, tMs, 320)
        if err != nil {
                return "", err
        }
        return "/local/thumbs/" + filepath.Base(path), nil
}

// ---------------------------------------------------------------------------
// Timeline
// ---------------------------------------------------------------------------

// AddClip thêm clip từ asset vào vị trí atIndex (-1 = cuối timeline).
// Video: mặc định toàn bộ; ảnh: 5 giây.
func (a *App) AddClip(assetID string, atIndex int) (*project.Clip, error) {
        a.mu.Lock()
        as := a.doc.FindAsset(assetID)
        if as == nil {
                a.mu.Unlock()
                return nil, fmt.Errorf("không tìm thấy tư liệu %s", assetID)
        }
        if as.Missing {
                a.mu.Unlock()
                return nil, fmt.Errorf("tệp nguồn không còn: %s", as.Path)
        }
        in, out := int64(0), as.DurationMs
        if as.Kind == project.AssetImage {
                out = 5000
        }
        if out <= 0 {
                a.mu.Unlock()
                return nil, errors.New("tư liệu có thời lượng 0, không thể thêm vào timeline")
        }
        c := &project.Clip{
                ID:       project.NewID("c"),
                AssetID:  assetID,
                InMs:     in,
                OutMs:    out,
                Volume:   1,
                Transform: project.Transform{Zoom: 1},
        }
        n := len(a.doc.Clips)
        if atIndex < 0 || atIndex > n {
                atIndex = n
        }
        // Chèn: cắt mảng.
        a.doc.Clips = append(a.doc.Clips, c)
        copy(a.doc.Clips[atIndex+1:], a.doc.Clips[atIndex:])
        a.doc.Clips[atIndex] = c
        a.mu.Unlock()
        if err := a.persist(); err != nil {
                return nil, err
        }
        return c, nil
}

// ClipPatch là bản vá thuộc tính clip — trường nil = không đổi.
type ClipPatch struct {
        InMs      *int64   `json:"inMs"`
        OutMs     *int64   `json:"outMs"`
        Mute      *bool    `json:"mute"`
        Volume    *float64 `json:"volume"`
        RotateDeg *float64 `json:"rotateDeg"`
        FlipH     *bool    `json:"flipH"`
        FlipV     *bool    `json:"flipV"`
        Zoom      *float64 `json:"zoom"`
        // v1.1
        Speed          *float64               `json:"speed"`
        Reverse        *bool                  `json:"reverse"`
        Boomerang      *bool                  `json:"boomerang"`
        LoopN          *int                   `json:"loopN"`
        FreezeStartMs  *int64                 `json:"freezeStartMs"`
        FreezeEndMs    *int64                 `json:"freezeEndMs"`
        AudioFadeInMs  *int64                 `json:"audioFadeInMs"`
        AudioFadeOutMs *int64                 `json:"audioFadeOutMs"`
        WaterDropMs    *int64                 `json:"waterDropMs"`
        Effects        *project.ClipEffects   `json:"effects"`
        LUTPath        *string                `json:"lutPath"`
        Keyframes      *[]project.KeyframePoint `json:"keyframes"`
}

// UpdateClip áp bản vá cho clip.
func (a *App) UpdateClip(id string, patch ClipPatch) (*project.Clip, error) {
        a.mu.Lock()
        c := a.doc.FindClip(id)
        if c == nil {
                a.mu.Unlock()
                return nil, fmt.Errorf("không tìm thấy clip %s", id)
        }
        as := a.doc.FindAsset(c.AssetID)
        maxDur := int64(0)
        isImage := false
        if as != nil {
                maxDur = as.DurationMs
                isImage = as.Kind == project.AssetImage
        }
        if isImage {
                maxDur = 10 * 60 * 1000 // ảnh: giới hạn ảo 10 phút
        }
        if patch.InMs != nil {
                v := *patch.InMs
                if v < 0 {
                        v = 0
                }
                c.InMs = v
        }
        if patch.OutMs != nil {
                v := *patch.OutMs
                if v > maxDur {
                        v = maxDur
                }
                c.OutMs = v
        }
        if c.OutMs-c.InMs < 100 {
                c.OutMs = c.InMs + 100
                if !isImage && maxDur > 0 && c.OutMs > maxDur {
                        c.InMs = maxDur - 100
                        c.OutMs = maxDur
                }
        }
        if patch.Mute != nil {
                c.Mute = *patch.Mute
        }
        if patch.Volume != nil {
                v := *patch.Volume
                if v < 0 {
                        v = 0
                }
                if v > 2 {
                        v = 2
                }
                c.Volume = v
        }
        if patch.RotateDeg != nil {
                c.Transform.RotateDeg = *patch.RotateDeg
        }
        if patch.FlipH != nil {
                c.Transform.FlipH = *patch.FlipH
        }
        if patch.FlipV != nil {
                c.Transform.FlipV = *patch.FlipV
        }
        if patch.Zoom != nil {
                c.Transform.Zoom = *patch.Zoom
        }
        // v1.1: thuộc tính thời gian / hiệu ứng / keyframes.
        if patch.Speed != nil {
                s := *patch.Speed
                if s < 0.25 {
                        s = 0.25
                }
                if s > 4 {
                        s = 4
                }
                c.Speed = s
        }
        if patch.Reverse != nil {
                c.Reverse = *patch.Reverse
        }
        if patch.Boomerang != nil {
                c.Boomerang = *patch.Boomerang
        }
        if patch.LoopN != nil {
                n := *patch.LoopN
                if n < 1 {
                        n = 1
                }
                if n > 20 {
                        n = 20
                }
                c.LoopN = n
                if n > 1 {
                        c.Boomerang = false
                }
        }
        if c.Boomerang {
                c.LoopN = 1
        }
        if patch.FreezeStartMs != nil {
                v := *patch.FreezeStartMs
                if v < 0 {
                        v = 0
                }
                if v > 30000 {
                        v = 30000
                }
                c.FreezeStartMs = v
        }
        if patch.FreezeEndMs != nil {
                v := *patch.FreezeEndMs
                if v < 0 {
                        v = 0
                }
                if v > 30000 {
                        v = 30000
                }
                c.FreezeEndMs = v
        }
        if patch.AudioFadeInMs != nil {
                v := *patch.AudioFadeInMs
                if v < 0 {
                        v = 0
                }
                if v > 60000 {
                        v = 60000
                }
                c.AudioFadeInMs = v
        }
        if patch.AudioFadeOutMs != nil {
                v := *patch.AudioFadeOutMs
                if v < 0 {
                        v = 0
                }
                if v > 60000 {
                        v = 60000
                }
                c.AudioFadeOutMs = v
        }
        if patch.WaterDropMs != nil {
                v := *patch.WaterDropMs
                if v < 0 {
                        v = 0
                }
                if v > 30000 {
                        v = 30000
                }
                c.WaterDropMs = v
        }
        if patch.Effects != nil {
                c.Effects = patch.Effects.Normalize()
        }
        if patch.LUTPath != nil {
                c.LUTPath = strings.TrimSpace(*patch.LUTPath)
                if c.LUTPath != "" {
                        if _, err := os.Stat(c.LUTPath); err != nil {
                                c.LUTPath = ""
                                a.mu.Unlock()
                                return nil, errors.New("file LUT .cube không tồn tại")
                        }
                }
        }
        if patch.Keyframes != nil {
                ks := make([]project.KeyframePoint, 0, len(*patch.Keyframes))
                for _, k := range *patch.Keyframes {
                        if k.Prop != "scale" && k.Prop != "opacity" {
                                continue
                        }
                        if k.AtMs < 0 {
                                k.AtMs = 0
                        }
                        if k.Prop == "scale" && (k.Val < 0.1 || k.Val > 4) {
                                k.Val = 1
                        }
                        if k.Prop == "opacity" && (k.Val < 0 || k.Val > 1) {
                                k.Val = 1
                        }
                        ks = append(ks, k)
                }
                c.Keyframes = ks
        }
        c.Transform = c.Transform.Normalize()
        a.mu.Unlock()
        if err := a.persist(); err != nil {
                return nil, err
        }
        return c, nil
}

// MoveClip di chuyển clip tới vị trí toIndex.
func (a *App) MoveClip(id string, toIndex int) error {
        a.mu.Lock()
        defer a.mu.Unlock()
        i := a.doc.ClipIndex(id)
        if i < 0 {
                return fmt.Errorf("không tìm thấy clip %s", id)
        }
        n := len(a.doc.Clips)
        if toIndex < 0 {
                toIndex = 0
        }
        if toIndex >= n {
                toIndex = n - 1
        }
        if toIndex == i {
                return a.persist()
        }
        // Bước 1: gỡ khỏi vị trí i.
        c := a.doc.Clips[i]
        a.doc.Clips = append(a.doc.Clips[:i], a.doc.Clips[i+1:]...)
        // Bước 2: chèn lại tại toIndex.
        a.doc.Clips = append(a.doc.Clips, nil)
        copy(a.doc.Clips[toIndex+1:], a.doc.Clips[toIndex:])
        a.doc.Clips[toIndex] = c
        a.doc.SortTransitions()
        return a.persist()
}

// RemoveClip xoá clip (kèm chuyển cảnh nối vào nó).
func (a *App) RemoveClip(id string) error {
        a.mu.Lock()
        i := a.doc.ClipIndex(id)
        if i < 0 {
                a.mu.Unlock()
                return fmt.Errorf("không tìm thấy clip %s", id)
        }
        a.doc.Clips = append(a.doc.Clips[:i], a.doc.Clips[i+1:]...)
        a.doc.RemoveTransitionAfter(id)
        a.doc.Transitions = cleanTransitions(a.doc)
        a.mu.Unlock()
        return a.persist()
}

// SplitClip tách clip tại vị trí timelineMs; trả về clip mới (nửa trái).
func (a *App) SplitClip(id string, timelineMs int64) (*project.Clip, error) {
        a.mu.Lock()
        i := a.doc.ClipIndex(id)
        if i < 0 {
                a.mu.Unlock()
                return nil, fmt.Errorf("không tìm thấy clip %s", id)
        }
        starts := a.doc.TimelineMsPerClip()
        c := a.doc.Clips[i]
        local := timelineMs - starts[i]
        if local <= c.InMs+80 || local >= c.OutMs-80 {
                a.mu.Unlock()
                return nil, errors.New("vị trí tách quá sát đầu/cuối clip")
        }
        left := *c
        left.ID = project.NewID("c")
        left.OutMs = local
        right := *c
        right.InMs = local
        a.doc.Clips[i] = &right
        a.doc.Clips = append(a.doc.Clips, nil)
        copy(a.doc.Clips[i+1:], a.doc.Clips[i:])
        a.doc.Clips[i] = &left
        a.mu.Unlock()
        if err := a.persist(); err != nil {
                return nil, err
        }
        return &left, nil
}

// TransInfo là thông tin 1 chuyển cảnh cho dropdown UI.
type TransInfo struct {
        Type string `json:"type"`
        Name string `json:"name"`
}

// ListTransitions trả danh sách chuyển cảnh hỗ trợ (tiếng Việt).
func (a *App) ListTransitions() []TransInfo {
        list := []TransInfo{
                {Type: "none", Name: "— Không có —"},
                {Type: string(project.TransCrossfade), Name: "Hòa mềm (Crossfade)"},
                {Type: string(project.TransDissolve), Name: "Tan biến (Dissolve)"},
                {Type: string(project.TransFadeThroughBlk), Name: "Qua đen (Fade qua đen)"},
                {Type: string(project.TransWipeLeft), Name: "Trượt khoá — sang trái"},
                {Type: string(project.TransWipeRight), Name: "Trượt khoá — sang phải"},
                {Type: string(project.TransWipeUp), Name: "Trượt khoá — lên"},
                {Type: string(project.TransWipeDown), Name: "Trượt khoá — xuống"},
                {Type: string(project.TransSlideLeft), Name: "Trượt khung — sang trái"},
                {Type: string(project.TransSlideRight), Name: "Trượt khung — sang phải"},
                {Type: string(project.TransSlideUp), Name: "Trượt khung — lên"},
                {Type: string(project.TransSlideDown), Name: "Trượt khung — xuống"},
                {Type: string(project.TransPushLeft), Name: "Đẩy — sang trái"},
                {Type: string(project.TransPushRight), Name: "Đẩy — sang phải"},
                {Type: string(project.TransPushUp), Name: "Đẩy — lên"},
                {Type: string(project.TransPushDown), Name: "Đẩy — xuống"},
                {Type: string(project.TransIrisOpen), Name: "Mống mở (Iris mở)"},
                {Type: string(project.TransIrisClose), Name: "Mống đóng (Iris đóng)"},
        }
        return list
}

// SetTransition đặt/xoá chuyển cảnh sau afterClipID. typeName "none" = xoá.
func (a *App) SetTransition(afterClipID string, typeName string, durMs int64) error {
        a.mu.Lock()
        defer a.mu.Unlock()
        i := a.doc.ClipIndex(afterClipID)
        if i < 0 {
                return fmt.Errorf("không tìm thấy clip %s", afterClipID)
        }
        if i == len(a.doc.Clips)-1 || typeName == "none" || typeName == "" {
                a.doc.RemoveTransitionAfter(afterClipID)
                a.doc.Transitions = cleanTransitions(a.doc)
                return a.persist()
        }
        t, ok := parseTransition(typeName)
        if !ok {
                return fmt.Errorf("loại chuyển cảnh không hỗ trợ: %s", typeName)
        }
        // Giới hạn thời lượng an toàn.
        limit := a.doc.Clips[i].DurationMs()
        if i+1 < len(a.doc.Clips) {
                if n := a.doc.Clips[i+1].DurationMs(); n < limit {
                        limit = n
                }
        }
        if durMs < 120 {
                durMs = 300
        }
        if durMs > limit-120 {
                durMs = limit - 120
        }
        if durMs < 120 {
                return errors.New("clip quá ngắn để áp chuyển cảnh")
        }
        if ex := a.doc.TransitionAfter(afterClipID); ex != nil {
                ex.Type = t
                ex.DurationMs = durMs
        } else {
                a.doc.Transitions = append(a.doc.Transitions, &project.Transition{
                        AfterClipID: afterClipID, Type: t, DurationMs: durMs,
                })
        }
        a.doc.SortTransitions()
        return a.persist()
}

// cleanTransitions loại transition trỏ tới clip không tồn tại.
func cleanTransitions(doc *project.Document) []*project.Transition {
        out := doc.Transitions[:0]
        for _, t := range doc.Transitions {
                if doc.FindClip(t.AfterClipID) != nil {
                        out = append(out, t)
                }
        }
        return out
}

// parseTransition map chuỗi type sang project.TransitionType.
func parseTransition(s string) (project.TransitionType, bool) {
        t := project.TransitionType(s)
        switch t {
        case project.TransCrossfade, project.TransDissolve, project.TransFadeThroughBlk,
                project.TransWipeLeft, project.TransWipeRight, project.TransWipeUp, project.TransWipeDown,
                project.TransSlideLeft, project.TransSlideRight, project.TransSlideUp, project.TransSlideDown,
                project.TransPushLeft, project.TransPushRight, project.TransPushUp, project.TransPushDown,
                project.TransIrisOpen, project.TransIrisClose:
                return t, true
        }
        return "", false
}

// ---------------------------------------------------------------------------
// Tiện ích hệ thống
// ---------------------------------------------------------------------------

// OpenInFolder mở Explorer tại file/thư mục.
func (a *App) OpenInFolder(path string) error {
        if _, err := os.Stat(path); err != nil {
                return err
        }
        switch runtime.GOOS {
        case "windows":
                return exec.Command("explorer", "/select,", path).Start()
        case "darwin":
                return exec.Command("open", "-R", path).Start()
        default:
                return exec.Command("xdg-open", filepath.Dir(path)).Start()
        }
}

// GetVersion trả phiên bản app.
func (a *App) GetVersion() string { return a.version }

// AppVersion được set lúc build bằng ldflags.
var AppVersion = "1.1.0"

// nowMs helper.
func nowMs() int64 { return time.Now().UnixNano() / 1e6 }
