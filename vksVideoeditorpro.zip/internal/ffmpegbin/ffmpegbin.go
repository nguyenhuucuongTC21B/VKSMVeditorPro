// Package ffmpegbin nhúng sẵn ffmpeg.exe + ffprobe.exe (Windows, build
// essentials của gyan.dev) trong chính tệp .exe thông qua go:embed, và tự
// giải nén vào thư mục cache của người dùng (%LOCALAPPDATA% trên Windows)
// ở lần chạy đầu tiên. Đây là chìa khoá để VKSeditorPro thỏa mãn yêu cầu
// "một tệp .exe duy nhất": không cần cài FFmpeg, không cần internet.
package ffmpegbin

import (
	"archive/zip"
	"bytes"
	"crypto/sha256"
	_ "embed"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"runtime"
)

//go:embed ffmpeg-essentials.zip
var embeddedZip []byte

// markerVersion thay đổi khi nâng cấp bundle để buộc giải nén lại.
const markerVersion = "ffmpeg-essentials-9.0.2-v1"

// Result là kết quả giải nén.
type Result struct {
	FFmpegPath  string
	FFprobePath string
	Dir         string
	Extracted   bool // true nếu lần này mới giải nén (lần đầu chạy)
}

// targetDir trả thư mục đích giải nén:
// Windows: %LOCALAPPDATA%\VKSeditorPro\bin — Linux/macOS: ~/.cache/VKSeditorPro/bin
func targetDir() (string, error) {
	base, err := os.UserCacheDir()
	if err != nil {
		return "", err
	}
	return filepath.Join(base, "VKSeditorPro", "bin"), nil
}

// Ensure đảm bảo ffmpeg/ffprobe sẵn sàng trên đĩa và trả về đường dẫn.
// Người gọi PHẢI set MGO_FFMPEG / MGO_FFPROBE bằng kết quả này TRƯỚC khi
// gọi bất kỳ hàm nào của moviego (moviego cache kết quả lần đầu tra cứu).
func Ensure(logf func(format string, args ...any)) (*Result, error) {
	dir, err := targetDir()
	if err != nil {
		return nil, err
	}
	if err := os.MkdirAll(dir, 0o755); err != nil {
		return nil, fmt.Errorf("tạo thư mục %s: %w", dir, err)
	}

	ffmpegPath := filepath.Join(dir, "ffmpeg.exe")
	ffprobePath := filepath.Join(dir, "ffprobe.exe")
	if runtime.GOOS != "windows" {
		// Bản test trên Linux dùng tên không đuôi.
		ffmpegPath = filepath.Join(dir, "ffmpeg")
		ffprobePath = filepath.Join(dir, "ffprobe")
	}

	marker := filepath.Join(dir, "marker.txt")
	if data, err := os.ReadFile(marker); err == nil && string(data) == markerVersion {
		if ok(ffmpegPath) && ok(ffprobePath) {
			return &Result{FFmpegPath: ffmpegPath, FFprobePath: ffprobePath, Dir: dir, Extracted: false}, nil
		}
	}

	if logf != nil {
		logf("Giải nén FFmpeg vào %s (chỉ lần đầu chạy)...", dir)
	}
	if err := extractTwo(ffmpegPath, ffprobePath); err != nil {
		return nil, err
	}
	_ = os.WriteFile(marker, []byte(markerVersion), 0o644)
	if logf != nil {
		logf("FFmpeg đã sẵn sàng: %s", ffmpegPath)
	}
	return &Result{FFmpegPath: ffmpegPath, FFprobePath: ffprobePath, Dir: dir, Extracted: true}, nil
}

func ok(p string) bool {
	st, err := os.Stat(p)
	return err == nil && st.Size() > 1<<20 // > 1MB
}

// extractTwo giải nén đúng 2 tệp ffmpeg.exe và ffprobe.exe từ zip nhúng.
func extractTwo(ffmpegPath, ffprobePath string) error {
	zr, err := zip.NewReader(bytes.NewReader(embeddedZip), int64(len(embeddedZip)))
	if err != nil {
		return fmt.Errorf("mở zip FFmpeg nhúng: %w", err)
	}
	want := map[string]string{
		"ffmpeg.exe":  ffmpegPath,
		"ffprobe.exe": ffprobePath,
	}
	found := map[string]bool{}
	for _, f := range zr.File {
		base := filepath.Base(f.Name)
		dst, okw := want[base]
		if !okw || found[base] {
			continue
		}
		if err := extractFile(f, dst); err != nil {
			return err
		}
		found[base] = true
	}
	if !found["ffmpeg.exe"] || !found["ffprobe.exe"] {
		return errors.New("zip FFmpeg thiếu ffmpeg.exe hoặc ffprobe.exe")
	}
	return nil
}

// extractFile giải nén một entry, ghi qua tệp tạm rồi rename (atomic),
// kèm xác thực SHA-256 kích thước tối thiểu để tránh tệp rác.
func extractFile(f *zip.File, dst string) error {
	rc, err := f.Open()
	if err != nil {
		return fmt.Errorf("mở %s trong zip: %w", f.Name, err)
	}
	defer rc.Close()

	tmp := dst + ".tmp"
	out, err := os.Create(tmp)
	if err != nil {
		return fmt.Errorf("ghi %s: %w", tmp, err)
	}
	h := sha256.New()
	n, err := io.Copy(io.MultiWriter(out, h), rc)
	if err != nil {
		_ = out.Close()
		_ = os.Remove(tmp)
		return fmt.Errorf("giải nén %s: %w", f.Name, err)
	}
	if err := out.Close(); err != nil {
		_ = os.Remove(tmp)
		return err
	}
	if n < 1<<20 {
		_ = os.Remove(tmp)
		return fmt.Errorf("%s quá nhỏ (%d byte) — zip hỏng", f.Name, n)
	}
	_ = os.Remove(dst)
	if err := os.Rename(tmp, dst); err != nil {
		_ = os.Remove(tmp)
		return err
	}
	_ = os.Chmod(dst, 0o755)
	return nil
}
